<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rutina extends Model
{
    protected $fillable = ['ejercicio1_id', 'ejercicio2_id', 'ejercicio3_id', 'ejercicio4_id', 'ejercicio5_id', 'ejercicio6_id', 'ejercicio7_id', 'ejercicio8_id', 'ejercicio9_id', 'ejercicio10_id'];

}
