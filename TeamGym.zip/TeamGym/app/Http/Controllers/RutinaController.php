<?php

namespace App\Http\Controllers;

use App\Ejercicio;
use App\EjercicioModalidad;
use App\Entreno;
use App\Grupo;
use App\Http\Controllers\Controller;
use App\Modalidad;
use App\Rutina;
use App\Semana;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RutinaController extends Controller
{
    public function index($id)
    {

        //$rutinas = rutina::get();

        $rutina = User::find($id)->rutina;
        return view('rutina/index', ['rutinas' => $rutina]);
    }
    public function indice()
    {

        $ejercicio = Ejercicio::get();
        $grupos    = Grupo::get();
        $rutinas   = Rutina::get();
        return view('rutina/index', ['rutinas' => $rutinas], ['ejercicio' => $ejercicio], ['grupos' => $grupos]);
    }

    public function show(Request $request, $id)
    {
        $rutinas    = new Rutina;
        $rutina     = $rutinas->find($id);
        $user       = User::get();
        $ejercicios = Ejercicio::get();

        return view('rutina/editar', ['rutina' => $rutina], ['ejercicios' => $ejercicios]);

    }
    public function listar()
    {
        $ejercicios = Ejercicio::get();
        $rutina     = Rutina::get();
        return view('rutina/nuevo', ['rutinas' => $rutina], ['ejercicios' => $ejercicios]);

    }

    public function store(Request $request)
    {
        request()->validate([
            'ejercicio1_id'  => 'required',
            'ejercicio2_id'  => 'required',
            'ejercicio3_id'  => 'required',
            'ejercicio4_id'  => 'required',
            'ejercicio5_id'  => 'required',
            'ejercicio6_id'  => 'required',
            'ejercicio7_id'  => 'required',
            'ejercicio8_id'  => 'required',
            'ejercicio9_id'  => 'required',
            'ejercicio10_id' => 'required',
        ]);
        Rutina::create($request->all());
        /**$data = [
        'name'      => Input::get('name'),
        'user_id' => Input::get('user_id'),
        ];

        rutina::create($data);*/

        return redirect('home');

    }

    public function update(Request $request, $id)
    {

        Rutina::where('id', $id)->update(['ejercicio1_id' => Input::get('ejercicio1_id'), 'ejercicio2_id' => Input::get('ejercicio2_id'), 'ejercicio3_id' => Input::get('ejercicio3_id'), 'ejercicio4_id' => Input::get('ejercicio4_id'), 'ejercicio5_id' => Input::get('ejercicio5_id'), 'ejercicio6_id' => Input::get('ejercicio6_id'), 'ejercicio7_id' => Input::get('ejercicio7_id'), 'ejercicio8_id' => Input::get('ejercicio8_id'), 'ejercicio9_id' => Input::get('ejercicio9_id'), 'ejercicio10_id' => Input::get('ejercicio10_id')]);
        //return Redirect::route('rutina_editar', ['rutina_editar' => $id]);
        // return Redirect::route('user_rutina', ['rutina_editar' => $id]);
        return redirect(' / ');
    }

    public function destroy($id)
    {
        Rutina::destroy($id);

        return redirect(' / ');
    }

    /**public function comprovar(Request $request)
    {
    $usuarios = Usuario::get();
    //$user     = $request->input('usuario');
    //$pwd      = $request->input('pwd');
    //$food = Food::create($input);
    $result = "";
    foreach ($usuarios as $usuario) {

    if ($user == $usuario['usuario'] && $pwd == $usuario['psw']) {
    $result = "tot OK";
    break;
    } else {
    $result = "no coincideix";
    }

    }return view('indice/crear')->with(['resultado' => $result, 'usuarios' => $usuarios, 'user' => $user]);
    }*/

    public function prueba()
    {

    }
    public function comprovar(Request $request)
    {

        //CONSULTAS SQL
        /*

        //usuarios
        $users = User::all();
        $users = User::get();
        //usuario 10
        $user = User::find(10);
        $user = User::all()->first();
        //Crear Registro
        $user = new User;
        $user->username = "user";
        $user->save();
        // save retorna un boolean, podrían usarlo así:
        if( $user->save() ){
        var_dump($user->id);
        }
        //Actualizar
        $user = User::find(10);
        $user->username = "new user";
        $user->save();/
        //eliminar
        $user = User::find(10);
        $user->delete();
        //WHERE
        $user = User::where("estado","=",1)->find(10);
        //DEVOLVVIENTDO INSTANCIAS
        $users = User::where("estado","=",1)->paginate(10);
        // En la vista
        foreach ($users as $key => $user) {
        // $user es una Instancia de la clase User
        }
        //ALGUNAS COLUMNAS
        $users = User::where("estado","=",1)->select("id","username")->paginate(10);
        // RAW
        //////
        $users = User::where("estado","=",1)
        ->select(DB::raw("id,username, DATE_FORMAT(created_at,'%d/%m/%Y %h:%i %p') AS fecha"))
        ->paginate(10);
        ´//OTRAS FUNCIONES
        $users = User::where("estado","=",1)
        ->whereNotNull('updated_at')
        ->whereNull('email')
        ->whereIn('id', [1, 2, 3])
        ->whereBetween('edad', [1, 30])
        ->where('username','like','%ad%')
        ->orderBy('username')
        ->orderBy('created_at','desc')
        ->skip(10)->take(5)
        ->get();
        //CONDICIONES EN CONSTA
        $users = User::where("estado","=",1);
        if($buscar)
        $users = $users->where('username','like','%ad%');
        $users = $users->get();
        //PARA QUE KLOS REGISTROS DEUELVA FORMATO ARRAY O JSON
        $users = User::where("estado","=",1)->get()->toArray();
        $users = User::where("estado","=",1)->get()->toJson();
        $users = User::where("estado","=",1)->first()->toArray();

        /////////////////////////////////////////////////////////
        //CONSULTAS CON JOIN y LEFT JOIN
        ////////////////////////////////////////////////////////

        $users = User::join("roles","users.roles_id","=","roles.id")
        ->where('users.estado','=',1)
        ->get();

        $users = User::leftJoin("roles","users.roles_id","=","roles.id")
        ->where('users.estado','=',1)
        ->get();

        $users = User::join("roles","users.roles_id","=","roles.id")
        ->leftJoin('posts',function($join){
        $join->on('users.posts_id','=','posts.id')->where('posts.estado','=',1);
        })
        ->where('users.estado','=',1)
        ->get();

        $users = User::join("roles","users.roles_id","=","roles.id")
        ->leftJoin(DB::raw("(SELECT * FROM posts where posts.estado=1) as posts"),function($join){
        $join->on('users.posts_id','=','posts.id');
        })
        ->where('users.estado','=',1)
        ->get();

        /////////////////////////////////////////////////////////
        //CONSULTAS VARIAS
        ////////////////////////////////////////
        DB::table('users')
        ->whereExists(function ($query) {
        $query->select(DB::raw(1))
        ->from('orders')
        ->whereRaw('orders.user_id = users.id');
        })
        ->get();

        $users = DB::table('orders')
        ->select('department', DB::raw('SUM(price) as total_sales'))
        ->groupBy('department')
        ->havingRaw('SUM(price) > 2500')
        ->get();
        //PARA ISERTAR UN EGISTRO
        DB::table('users')->insert(
        ['username' => 'editor', 'edad' => 20]
        );
        //ACTUALIZAR

         */
        //$user      = Sentry::getUser();
        //$idUsuario = $user->id;ç
        //ejercicios = Ejercicio::get();
        $rutina = Rutina::get();
        $semana = Semana::get();
        //$modalidad          = Modalidad::get();
        //$entreno = Entreno::get();
        //$ejerciciomodalidad = EjercicioModalidad::get();
        $user     = Auth::user();
        $usuarios = User::get();
        $id       = Auth::id();
        //////////////////////////////////////////////////////////////////
        //////////////////////CONSULTAS MODALIDA Y ENTRENO///////////////

        //Consultamios el id de lamodalidad                                                     <---- simplificatr consulta

        $id_modalidads = Modalidad::where('nombre', $user['modalidad'])
            ->get(['id']);

        ////////////////////////

        foreach ($id_modalidads as $modalidad) {
            # code...
            $consultaEntrenos = Entreno::where('modalidad_id', $modalidad['id'])
                ->get();
        }
        foreach ($consultaEntrenos as $entrenos) {

            if ($entrenos['nivel'] == $user['nivel']) {

                $entreno = $entrenos;
            }
        }
        /////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////
        foreach ($id_modalidads as $modalidad) {
            $ejerciciomodalidad = EjercicioModalidad::where('modalidad_id', $modalidad['id'])
                ->get(['ejercicio_id']);
        }

        foreach ($ejerciciomodalidad as $ejercicio) {
            $ejercicios[] = Ejercicio::where('id', $ejercicio['ejercicio_id'])
                ->get();
        }

        $arrayGruosMusculares = array();
        for ($i = 0; $i < 11; $i++) {
            $arrayGruosMusculares[$i] = Ejercicio::where('grupo_id', $i + 1)
                ->get();
        }

        $arrayEjerciciosGm = array();

        foreach ($arrayGruosMusculares as $k => $variable) {
            foreach ($variable as $key => $value) {

                if ($value['grupo_id'] == 1) {
                    $arrayEjerciciosGm[$k][$key] = $value;
                }
                if ($value['grupo_id'] == 2) {

                    $arrayEjerciciosGm[$k][$key] = $value;
                }
                if ($value['grupo_id'] == 3) {

                    $arrayEjerciciosGm[$k][$key] = $value;
                }
                if ($value['grupo_id'] == 4) {

                    $arrayEjerciciosGm[$k][$key] = $value;
                }
                if ($value['grupo_id'] == 5) {

                    $arrayEjerciciosGm[$k][$key] = $value;
                }
                if ($value['grupo_id'] == 6) {

                    $arrayEjerciciosGm[$k][$key] = $value;
                }
                if ($value['grupo_id'] == 7) {

                    $arrayEjerciciosGm[$k][$key] = $value;
                }
                if ($value['grupo_id'] == 9) {

                    $arrayEjerciciosGm[$k][$key] = $value;
                }
            }
        }

        $arrayBicepsPecho  = array();
        $arrayTricepsPecho = array();
        $arrayHombroAbs    = array();
        $sinAbsCuerpo      = array();
        $sinEspaldaCuerpo  = array();
        $sinPiernasCurpo   = array();
        $sinTroncoCuerpo   = array();

        $i = 0;
        $j = 0;
        $k = 0;
        $l = 0;
        $m = 0;
        $n = 0;
        $o = 0;
        $p = 0;
        while ($j < 70) {
            while ($i < 10) {
                $random = rand(1, 10);

                if ($i < 5) {
                    $arrayBicepsPecho[$i] = $arrayEjerciciosGm[0][$random];
                }
                if ($i > 5) {
                    $arrayBicepsPecho[$i] = $arrayEjerciciosGm[1][$random];
                }
                $i++;
            }
            while ($k < 10) {
                $random = rand(1, 10);

                if ($k < 5) {
                    $arrayTricepsEspalda[$k] = $arrayEjerciciosGm[1][$random];
                }
                if ($k > 5) {
                    $arrayTricepsEspalda[$i] = $arrayEjerciciosGm[1][$random];
                }
                $k++;
            }
            while ($l < 10) {
                $random = rand(1, 10);

                if ($l < 5) {
                    $arrayHombroAbs[$l] = $arrayEjerciciosGm[2][$random];
                }
                if ($l > 5) {
                    $arrayHombroAbs[$i] = $arrayEjerciciosGm[1][$random];
                }
                $l++;
            }
            while ($m < 10) {
                $random = rand(1, 10);

                if ($m < 5) {
                    $sinAbsCuerpo[$m] = $arrayEjerciciosGm[3][$random];
                }
                if ($l > 5) {
                    $sinAbsCuerpo[$i] = $arrayEjerciciosGm[1][$random];
                }
                $m++;
            }
            while ($n < 10) {
                $random = rand(1, 10);

                if ($n < 5) {

                    $sinEspaldaCuerpo[$n] = $arrayEjerciciosGm[3][$random];
                }
                if ($l > 5) {
                    $sinEspaldaCuerpo[$i] = $arrayEjerciciosGm[1][$random];
                }
                $n++;
            }
            while ($o < 10) {
                if ($o < 5) {

                    $random              = rand(1, 10);
                    $sinPiernasCurpo[$o] = $arrayEjerciciosGm[3][$random];
                }
                if ($l > 5) {
                    $sinPiernasCurpo[$i] = $arrayEjerciciosGm[1][$random];
                }
                $o++;
            }
            while ($p < 10) {
                if ($p < 5) {

                    $random              = rand(1, 10);
                    $sinTroncoCuerpo[$p] = $arrayEjerciciosGm[3][$random];
                }
                if ($l > 5) {
                    $sinTroncoCuerpo[$i] = $arrayEjerciciosGm[1][$random];
                }
                $p++;
            }
            $j++;
        }
        $rutina                 = new Rutina;
        $rutina->ejercicio1_id  = $arrayBicepsPecho[0]->id;
        $rutina->ejercicio2_id  = $arrayBicepsPecho[1]->id;
        $rutina->ejercicio3_id  = $arrayBicepsPecho[2]->id;
        $rutina->ejercicio4_id  = $arrayBicepsPecho[3]->id;
        $rutina->ejercicio5_id  = $arrayBicepsPecho[4]->id;
        $rutina->ejercicio7_id  = $arrayBicepsPecho[6]->id;
        $rutina->ejercicio8_id  = $arrayBicepsPecho[7]->id;
        $rutina->ejercicio9_id  = $arrayBicepsPecho[8]->id;
        $rutina->ejercicio10_id = $arrayBicepsPecho[9]->id;

/*
$biceps = Ejercicio::where('grupo_id', 2)
->get();
$triceps = Ejercicio::where('grupo_id', 3)
->get();
$espalda = Ejercicio::where('grupo_id', 4)
->get();
$hombro = Ejercicio::where('grupo_id', 5)
->get();
$pecho = Ejercicio::where('grupo_id', 6)
->get();
$piernas = Ejercicio::where('grupo_id', 7)
->get();
$spabdominales = Ejercicio::where('grupo_id', 8)
->get();
$spespalda = Ejercicio::where('grupo_id', 9)
->get();
$sppiernas = Ejercicio::where('grupo_id', 10)
->get();
$spcierpo = Ejercicio::where('grupo_id', 11)
->get();
$sptronco = Ejercicio::where('grupo_id', 12)
->get();

$cont1           = 0;
$cont2           = 0;
$cont3           = 0;
$cont4           = 0;
$cont5           = 0;
$cont6           = 0;
$cont7           = 0;
$cont8           = 0;
$cont9           = 0;
$cont10          = 0;
$cont11          = 0;
$cont12          = 0;
$random          = rand(1, 20);
$arrayejercicios = array
(
array("abs", ""),
array("biceps", ""),
array("triceps", ""),
array("espalda", ""),
array("pecho", ""),
array("hombro", ""),
array("piernas", ""),
array("sinpesasabs", ""),
array("sinpesasespalda", ""),
array("sinpesaspiernas", ""),
array("sinpesascuerpo", ""),
array("sinpesastronco", ""),
);
$arrayRepetidos = array(
array(),
);
//////////////////////////////////////////////
//recorremos el totald de ejerciccioa
while ($cont1 < 4) {
//queremos 4
while ($random > 13) {
$random = rand(1, 13);
}
$arrayejercicios[0][$cont1] = $abdominales[$random]; //ejercicios posicion randm
$cont1++;
$random                 = rand(1, 14); //actualizamos random
$arrayRepetidos[$cont1] = $random;
}

while ($cont2 < 4) {
if ($random > 16) {
$random = rand(1, 16);
}
//queremos 4
$arrayejercicios[1][$cont2] = $biceps[$random]; //ejercicios posicion randm
$cont2++;
$random                 = rand(1, 16); //actualizamos random
$arrayRepetidos[$cont2] = $random;
}

while ($cont3 < 4) {
if ($random > 11) {
$random = rand(1, 11);
}
//queremos 4
$arrayejercicios[2][$cont3] = $triceps[$random]; //ejercicios posicion randm
$cont3++;
$random                 = rand(1, 12); //actualizamos random
$arrayRepetidos[$cont3] = $random;
}
/////////
while ($cont4 < 4) {
if ($random > 11) {
$random = rand(1, 11);
}
//queremos 4
$arrayejercicios[3][$cont4] = $espalda[$random]; //ejercicios posicion randm
$cont4++;
$random                 = rand(1, 11); //actualizamos random
$arrayRepetidos[$cont4] = $random;
}
while ($cont5 < 4) {
if ($random > 18) {
$random = rand(1, 18);
}
//queremos 4
$arrayejercicios[4][$cont5] = $hombro[$random]; //ejercicios posicion randm
$cont5++;
$random                 = rand(1, 18); //actualizamos random
$arrayRepetidos[$cont5] = $random;
}
while ($cont6 < 4) {
if ($random > 10) {
$random = rand(1, 10);
}
//queremos 4
$arrayejercicios[5][$cont6] = $pecho[$random]; //ejercicios posicion randm
$cont6++;
$random                 = rand(1, 10); //actualizamos random
$arrayRepetidos[$cont6] = $random;
}
while ($cont7 < 4 && $random < 10) {
if ($random > 10) {
$random = rand(1, 10);
}
//queremos 4
$arrayejercicios[6][$cont7] = $piernas[$random]; //ejercicios posicion randm
$cont7++;
$random                 = rand(1, 10); //actualizamos random
$arrayRepetidos[$cont7] = $random;
}
while ($cont8 < 4) {
if ($random > 8) {
$random = rand(1, 8);
}
//queremos 4
$arrayejercicios[7][$cont8] = $spabdominales[$random]; //ejercicios posicion randm
$cont8++;
$random                 = rand(1, 8); //actualizamos random
$arrayRepetidos[$cont8] = $random;
}
while ($cont9 < 4) {
if ($random > 4) {
$random = rand(1, 4);
}
//queremos 4
$arrayejercicios[8][$cont9] = $spespalda[$random]; //ejercicios posicion randm
$cont9++;
$random                 = rand(1, 4); //actualizamos random
$arrayRepetidos[$cont9] = $random;
}
while ($cont10 < 4) {
if ($random > 8) {
$random = rand(1, 8);
}
//queremos 4
$arrayejercicios[9][$cont10] = $sppiernas[$random]; //ejercicios posicion randm
$cont10++;
$random                  = rand(1, 8); //actualizamos random
$arrayRepetidos[$cont10] = $random;
}
while ($cont11 < 4) {
if ($random > 4) {
$random = rand(1, 4);
}
//queremos 4
$arrayejercicios[10][$cont11] = $spcierpo[$random]; //ejercicios posicion randm
$cont11++;
$random                  = rand(1, 4); //actualizamos random
$arrayRepetidos[$cont11] = $random;
}
while ($cont12 < 4) {
if ($random > 3) {
$random = rand(1, 3);
}
//queremos 4
$arrayejercicios[11][$cont12] = $sptronco[$random]; //ejercicios posicion randm
$cont12++;
$random                  = rand(1, 3); //actualizamos random
$arrayRepetidos[$cont12] = $random;
}*/
        ///////////////////////////////////////////////////////////////////////////////////////////
        /*if ($random < 14) {
        $arrayejercicios[1][$cont2];

        }
        if ($random < 17) {
        $arrayejercicios[2][];

        }
        if ($random < 12) {
        $arrayejercicios[3][];

        }
        if ($random < 24) {
        $arrayejercicios[4][];

        }
        if ($random < 19) {
        $arrayejercicios[5][];

        }
        if ($random < 9) {
        $arrayejercicios[6][];

        }
        if ($random < 10) {
        $arrayejercicios[7][];

        }
        if ($random < 5) {
        $arrayejercicios[8][];

        }
        if ($random < 10) {
        $arrayejercicios[9][];

        }
        if ($random < 5) {
        $arrayejercicios[10][];

        }
        if ($random < 3) {
        $arrayejercicios[10][];

        }*/

        /**for ($k = 0; $i < 10; $i++) {
        if ($cont2 <= 4) {
        $arrayEjerciciosBiceps[$i] == $biceps[$random2];
        $cont2++;
        }
        if ($cont4 <= 4) {
        $arrayEjerciciosEspalda[$i] == $espalda[$random4];
        $cont4++;
        }
        }
        for ($i = 0; $i < 10; $i++) {
        if ($cont3 <= 4) {
        $arrayEjerciciosTriceps[$i] == $triceps[$random3];
        $cont3++;
        }
        if ($cont6 <= 4) {
        $arrayEjerciciosTriceps[$i] == $pecho[$random6];
        $cont6++;
        }
        }
        for ($i = 0; $i < 10; $i++) {
        if ($cont5 <= 4) {
        $arrayEjerciciosHombro[$i] == $hombro[$random5];
        $cont5++;
        }
        if ($cont10 <= 4) {
        $arrayEjerciciosSinPesasPiernas[$i] == $sppiernas[$random10];
        $cont10++;
        }
        }
        for ($i = 0; $i < 10; $i++) {
        if ($cont9 <= 4) {
        $arrayEjerciciosSiPesasasEspalda[$i] == $spespalda[$random9];
        $cont9++;
        }
        if ($cont11 <= 4) {
        $arrayEjerciciosSinpesasCuerpo[$i] == $spcierpo[$random11];
        $cont11++;
        }
        }
        for ($i = 0; $i < 10; $i++) {
        if ($cont8 <= 4) {
        $arrayEjerciciosSinPesasAbdominal[$i] == $spabdominales[$random8];
        $cont8++;
        }
        if ($cont12 <= 4) {
        $arrayEjerciciosSinPesasCuerpo[$i] == $sptronco[$random12];
        $cont12++;
        }
        }*/
        /**oreach ($ejercicios as $ejercicio) {
        foreach ($ejercicio as $ejer) {
        if ($ejer['grupo_id'] == 1) {
        $eabs = $ejer;
        }
        if ($ejer['grupo_id'] == 2) {
        $eBiceps = $ejer;
        }
        if ($ejer['grupo_id'] == 3) {
        $eTriceps = $ejer;
        }
        if ($ejer['grupo_id'] == 4) {
        $eEspalda = $ejer;
        }
        if ($ejer['grupo_id'] == 5) {
        $eHombro = $ejer;
        }
        if ($ejer['grupo_id'] == 6) {
        $ePecho = $ejer;
        }
        if ($ejer['grupo_id'] == 7) {
        $ePiernas = $ejer;
        }
        if ($ejer['grupo_id'] == 8) {
        $eSAbs = $ejer;
        }
        if ($ejer['grupo_id'] == 9) {
        $eSEspalda = $ejer;
        }
        if ($ejer['grupo_id'] == 10) {
        $eSPiernasGluteos = $ejer;
        }
        if ($ejer['grupo_id'] == 11) {
        $eSTodoCuerpo = $ejer;
        }
        if ($ejer['grupo_id'] == 12) {
        $eSTronco = $ejer;
        }

        }
        }*/
        ////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////
        //$entreno = Entreno::where('nivel', $user['nivel'])
        //->get(['id']);

        /*
        $id_modalidad = User::join("modalidads", "users.id", "=", "modalidads.id")
        ->where('users.modalidad', '=', $user['modalidad'])
        ->get();
        $users = User::join("roles", "users.roles_id", "=", "roles.id")
        ->where('users.estado', '=', 1)
        ->get();

        $users = User::leftJoin("roles", "users.roles_id", "=", "roles.id")
        ->where('users.estado', '=', 1)
        ->get();

        $users = User::join("roles", "users.roles_id", "=", "roles.id")
        ->leftJoin('posts', function ($join) {
        $join->on('users.posts_id', '=', 'posts.id')->where('posts.estado', '=', 1);
        })
        ->where('users.estado', '=', 1)
        ->get();

        $users = User::join("roles", "users.roles_id", "=", "roles.id")
        ->leftJoin(DB::raw("(SELECT * FROM posts where posts.estado=1) as posts"), function ($join) {
        $join->on('users.posts_id', '=', 'posts.id');
        })
        ->where('users.estado', '=', 1)
        ->get();
         */

// Get the currently authenticated user's ID...

        //$user     = $request->input('usuario');
        //$pwd      = $request->input('pwd');
        //$food = Food::create($input);
        //$result = "";
        //foreach ($usuarios as $usuario) {

        // if ($user == $usuario['usuario'] && $pwd == $usuario['psw']) {
        //   $result = "tot OK";
        // break;
        // } else {
        //   $result = "no coincideix";
        // }

        //}
        return view('rutina/crear')->with(['user' => $user, 'id' => $id, 'entreno' => $entreno, 'ejerciciomodalidad' => $ejerciciomodalidad, 'ejercicios' => $ejercicios, 'arrayBicepsPecho' => $arrayBicepsPecho, 'arrayTricepsEspalda' => $arrayTricepsEspalda, 'arrayHombroAbs' => $arrayHombroAbs, 'sinAbsCuerpo' => $sinAbsCuerpo, 'sinEspaldaCuerpo' => $sinEspaldaCuerpo, 'sinPiernasCurpo' => $sinPiernasCurpo, 'sinTroncoCuerpo' => $sinTroncoCuerpo]);
    }
}
