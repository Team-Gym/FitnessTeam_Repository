<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<h2>Ejercicios Rutina</h2>
			<table class="table table-striped">
					<tr>
						<th>ejercicio1_id</th>
						<th>ejercicio2_id</th>
						<th>ejercicio3_id</th>
						<th>ejercicio4_id</th>
						<th>ejercicio5_id</th>
						<th>ejercicio6_id</th>
						<th>ejercicio7_id</th>
						<th>ejercicio8_id</th>
						<th>ejercicio9_id</th>
						<th>ejercicio10_id</th>
						<th>Opciones</th>
					</tr>
					<?php $__currentLoopData = $rutinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rutina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($rutina['ejercicio1_id']); ?></td>
					    <td><?php echo e($rutina['ejercicio2_id']); ?></td>
						<td><?php echo e($rutina['ejercicio3_id']); ?></td>
						<td><?php echo e($rutina['ejercicio4_id']); ?></td>
						<td><?php echo e($rutina['ejercicio5_id']); ?></td>
						<td><?php echo e($rutina['ejercicio6_id']); ?></td>
						<td><?php echo e($rutina['ejercicio7_id']); ?></td>
						<td><?php echo e($rutina['ejercicio8_id']); ?></td>
						<td><?php echo e($rutina['ejercicio9_id']); ?></td>
						<td><?php echo e($rutina['ejercicio10_id']); ?></td>

						<td>
							<a href="<?php echo e(route('rutina_editar', ['id' => $rutina['id']])); ?>" class="btn btn-default">Editar</a>
							<a href="<?php echo e(route('rutina_eliminar', ['id' => $rutina['id']])); ?>" class="btn btn-danger">Eliminar</a>
						</td>
					</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>