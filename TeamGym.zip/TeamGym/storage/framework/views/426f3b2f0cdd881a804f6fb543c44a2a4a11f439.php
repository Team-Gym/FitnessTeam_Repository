<?php $__env->startSection('content'); ?>


<div class="container">



        <div class="col-md-12 px-0">
         <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"> <?php echo e($user['name']); ?></a>
              <div class="mb-1 text-muted">Inicio <?php echo e(date('d-m-Y', strtotime($user['created_at']))); ?></div>
              <p class="card-text mb-auto">Modalidad <?php echo e($user['modalidad']); ?></p>
              <p class="card-text mb-auto">Nivel <?php echo e($user['nivel']); ?></p>
              <a href="#">Saver mas</a>
            </div>
                <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('usuarios/usuario1.png')); ?>" alt="Card image cap">
          </div>



      </div>
      <div class="row mb-3">
        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[0]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[0]->ejercicio); ?></a>
                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[0]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[0]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[0]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[1]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[1]->ejercicio); ?></a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[1]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[1]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[1]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>
      <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[2]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[2]->ejercicio); ?></a>
                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[2]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[2]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[2]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[4]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[4]->ejercicio); ?></a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[4]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[4]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[4]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[6]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[6]->ejercicio); ?></a>
                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[6]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[6]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[6]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[7]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[7]->ejercicio); ?></a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[7]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[7]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[7]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>



      <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[8]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[8]->ejercicio); ?></a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[8]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[8]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[8]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>


        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[9]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[9]->ejercicio); ?></a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[9]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[9]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[9]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

      <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayBicepsPecho[9]->imagen)); ?>" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#"><?php echo e($arrayBicepsPecho[9]->ejercicio); ?></a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayBicepsPecho[9]->tiempo); ?> </div>
                    <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayBicepsPecho[9]->explicacion); ?></p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayBicepsPecho[9]->material); ?></p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>


    </div>



          </tr>

      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>