<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<h2>Notas de</h2>

			<table class="table table-striped">
					<tr>
						<th>ejercicio_id</th>
						<th>modlidad_id</th>
						<th>Opciones</th>
					</tr>

					<?php $__currentLoopData = $ejerciciomodalidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejerciciomodalidads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $modalidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($modalidads['id']==$ejerciciomodalidads['modalidad_id']): ?>
					<?php $modalidadNombre = $modalidads['nombre'];?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><img src="<?php echo e(URL::asset('rutinas/'.$ejercicios->imagen)); ?>"></td>
						<td><?php echo e($modalidadNombre); ?></td>
					</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>