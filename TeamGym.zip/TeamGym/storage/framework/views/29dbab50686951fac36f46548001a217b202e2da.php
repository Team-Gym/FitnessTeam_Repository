<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-12">

			<h2>Editar rutinas</h2>

			<table class="table table-striped">
					<tr>
						<th>Nombre</th>
						<th>apellido</th>
						<th>email</th>
						<th>sexo</th>
						<th>dob</th>
						<th>password</th>
						0
						<th>nivel</th>
						<th>Opciones</th>
					</tr>
					<tr>
					<form method="post">
						<?php echo e(csrf_field()); ?>

						<td><input type="text" name="name" value="<?php echo e($user['name']); ?>"></td>
						<td><input type="text" name="apellido" value="<?php echo e($user['apellido']); ?>"></td>
						<td><input type="text" name="email" value="<?php echo e($user['email']); ?>"></td>
						<td><input type="text" name="sexo" value="<?php echo e($user['sexo']); ?>"></td>
						<td><input type="date" name="dob" value="<?php echo e($user['dob']); ?>"></td>
						<td><input type="password" name="password" value="<?php echo e($user['password']); ?>"></td>
						<td><input type="text" name="modalidad" value="<?php echo e($user['modalidad']); ?>"></td>
						<td><input type="text" name="nivel" value="<?php echo e($user['nivel']); ?>"></td>
						<td>
							<input value="Editar" class="btn btn-default" type="submit"/>
						</td>
					</form>
					</tr>
			</table>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>