<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
nota
			<h2>Notas de</h2>

			<table class="table table-striped">
					<tr>
						<th>modalidada_id</th>
						<th>modlidad</th>
						<th>repeticiones</th>
						<th>series</th>
						<th>nivel</th>
						<th>peso</th>
						<th>Opciones</th>
					</tr>
					<?php $__currentLoopData = $entreno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrenos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $modalidads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($modalidad['id']==$entrenos['modalidad_id']): ?>
					<?php $modalidadNombre = $modalidad['nombre'];?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($entrenos['id']); ?></td>
						<td><?php echo e($modalidadNombre); ?></td>
						<td><?php echo e($entrenos['repeticiones']); ?></td>
						<td><?php echo e($entrenos['serie']); ?></td>
						<td><?php echo e($entrenos['nivel']); ?></td>
						<td><?php echo e($entrenos['peso']); ?></td>
						<td>
							<a href="<?php echo e(route('entreno_editar', ['id' => $entrenos['id']])); ?>" class="btn btn-default">Editar</a>
						</td>
					</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>