<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<h2></h2>
<?php
echo var_dump($ejercicios);
?>
 <?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-6">
	          <div class="card flex-md-row mb-4 box-shadow h-md-250">


		            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$ejercicio->imagen)); ?>" alt="Card image cap">

		            <div class="card-body d-flex flex-column align-items-start">
		              <strong class="d-inline-block mb-2 text-primary">World</strong>
		              <h3 class="mb-0">
		                <a class="text-dark" href="#"><?php echo e($ejercicio['ejercicio']); ?></a>
		              </h3>
		              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($ejercicio['tiempo']); ?> </div>
		              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($ejercicio['explicacion']); ?></p>
		              <p></p>
		              <p class="card-text mb-auto"><b>Material: </b><?php echo e($ejercicio['material']); ?></p>
		              <a href="#">Continue reading</a>

		            </div>

		          </div>
		      </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<table class="table table-striped">
					<tr>
						<th>ejercicio_id</th>
						<th>modalidad_id</th>
						<th>Opciones</th>
					</tr>
					<?php $__currentLoopData = $ejerciciomodalidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejerciciomodalidads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($ejerciciomodalidads['ejercicio_id']); ?></td>
						<td><?php echo e($ejerciciomodalidads['modalidad_id']); ?></td>
					</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>