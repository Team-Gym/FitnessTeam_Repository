<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-12">

			<h2>Agregar Rutina</h2>

			<form method="post">
					<?php echo e(csrf_field()); ?>



					<div class="form-group">

				    <label for="ejercicio1_id" >ejercicio1_id</label>

				    <select name="ejercicio1_id" id="ejercicio1_id" class="form-control" value="<?php echo e(Input::old('ejercicio1_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio2_id" >ejercicio2_id</label>

				    <select name="ejercicio2_id" id="ejercicio2_id" class="form-control" value="<?php echo e(Input::old('ejercicio2_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio3_id" >ejercicio3_id</label>

				    <select name="ejercicio3_id" id="ejercicio3_id" class="form-control" value="<?php echo e(Input::old('ejercicio3_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio4_id" >ejercicio4_id</label>

				    <select name="ejercicio4_id" id="ejercicio4_id" class="form-control" value="<?php echo e(Input::old('ejercicio4_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio5_id" >ejercicio5_id</label>

				    <select name="ejercicio5_id" id="ejercicio5_id" class="form-control" value="<?php echo e(Input::old('ejercicio5_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio6_id" >ejercicio6_id</label>

				    <select name="ejercicio6_id" id="ejercicio6_id" class="form-control" value="<?php echo e(Input::old('ejercicio6_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio7_id" >ejercicio7_id</label>

				    <select name="ejercicio7_id" id="ejercicio7_id" class="form-control" value="<?php echo e(Input::old('ejercicio7_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio8_id" >ejercicio8_id</label>

				    <select name="ejercicio8_id" id="ejercicio8_id" class="form-control" value="<?php echo e(Input::old('ejercicio8_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio9_id" >ejercicio9_id</label>

				    <select name="ejercicio9_id" id="ejercicio9_id" class="form-control" value="<?php echo e(Input::old('ejercicio9_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>
				  <div class="form-group">

				    <label for="ejercicio10_id" >ejercicio10_id</label>

				    <select name="ejercicio10_id" id="ejercicio10_id" class="form-control" value="<?php echo e(Input::old('ejercicio10_id')); ?>">

				    			<?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<option value="<?php echo e($ejercicio['id']); ?>" <?php if($ejercicio=='$ejercicio["id"]'): ?>selected <?php endif; ?> ><?php echo e($ejercicio['ejercicio']); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>

				  </div>


					 <input class="btn btn-default" type="submit" value="Enviar" />


				</form>

						</div>
					</div>
			</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>