<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">

			<h2>usuarios</h2>

			<table class="table table-striped">
					<tr>
						<th>Id</th>
						<th>grupomuscular</th>
						<th>ejercicio</th>
						<th>imagen</th>
						<th>explicacion</th>
						<th>tiempo</th>
						<th>material</th>
						<th>posicion</th>
						<th>consejo</th>
						<th>Opciones</th>
					</tr>
					<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $nombreGrupo = $grupo['grupo'];?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php $__currentLoopData = $ejercicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<tr>
						<td><?php echo e($ejercicios['id']); ?></td>
						<td><?php echo e($nombreGrupo); ?></td>
						<td><?php echo e($ejercicios['ejercicios']); ?></td>
						<td><img src="<?php echo e(URL::asset('rutinas/'.$ejercicios->imagen)); ?>"></td>
						<td><?php echo e($ejercicios['explicacion']); ?></td>
						<td><?php echo e($ejercicios['tiempo']); ?></td>
						<td><?php echo e($ejercicios['material']); ?></td>
						<td><?php echo e($ejercicios['posicion']); ?></td>
						<td><?php echo e($ejercicios['consejo']); ?></td>
						<td>
							<a href="<?php echo e(route('ejercicio_ejerciciomodalida', ['id' => $ejercicios['id']])); ?>" class="btn btn-default">Ver ejercicios de la modalidad
						</td>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tr>




			</table>


		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>