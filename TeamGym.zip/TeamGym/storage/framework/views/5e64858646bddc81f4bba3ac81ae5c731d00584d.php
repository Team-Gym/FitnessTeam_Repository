<?php $__env->startSection('content'); ?>


<div class="container">
      <header class="blog-header py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
          <div class="col-4 pt-1">
            <a class="text-muted" href="#">Subscribe</a>
          </div>
          <div class="col-4 text-center">
            <a class="blog-header-logo text-dark" href="#">Usuario</a>
          </div>
          <div class="col-4 d-flex justify-content-end align-items-center">
            <a class="text-muted" href="#">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mx-3"><circle cx="10.5" cy="10.5" r="7.5"></circle><line x1="21" y1="21" x2="15.8" y2="15.8"></line></svg>
            </a>
            <a class="btn btn-sm btn-outline-secondary" href="#">Sign up</a>
          </div>
        </div>
      </header>

      <div class="nav-scroller py-1 mb-2">
        <nav class="nav d-flex justify-content-between">
          <a class="p-2 text-muted" href="#">World</a>
          <a class="p-2 text-muted" href="#">U.S.</a>
          <a class="p-2 text-muted" href="#">Technology</a>
          <a class="p-2 text-muted" href="#">Design</a>
          <a class="p-2 text-muted" href="#">Culture</a>
          <a class="p-2 text-muted" href="#">Business</a>
          <a class="p-2 text-muted" href="#">Politics</a>
          <a class="p-2 text-muted" href="#">Opinion</a>
          <a class="p-2 text-muted" href="#">Science</a>
          <a class="p-2 text-muted" href="#">Health</a>
          <a class="p-2 text-muted" href="#">Style</a>
          <a class="p-2 text-muted" href="#">Travel</a>
        </nav>
      </div>


        <div class="col-md-12 px-0">
         <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"> <?php echo e($user['name']); ?></a>
              <div class="mb-1 text-muted">Inicio <?php echo e(date('d-m-Y', strtotime($user['created_at']))); ?></div>
              <p class="card-text mb-auto">Modalidad <?php echo e($user['modalidad']); ?></p>
              <p class="card-text mb-auto">Nivel <?php echo e($user['nivel']); ?></p>
              <a href="#">Saver mas</a>
            </div>
                <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('usuarios/usuario1.png')); ?>" alt="Card image cap">
          </div>



      </div>

            <?php
$arrayEjercicios = array();

for ($i = 0; $i < count($ejercicios); $i++) {
    $arrayEjercicios[$i] = $ejercicios[$i];
    //echo $arrayEjercicios[$i];
}
?>
      <div class="row mb-2">
        <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <?php $__currentLoopData = $arrayEjercicios[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>
              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <p></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
                <?php $__currentLoopData = $arrayEjercicios[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>
              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>
      </div>
      <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
                <?php $__currentLoopData = $arrayEjercicios[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>
              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
          <?php $__currentLoopData = $arrayEjercicios[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>
              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>
      <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <?php $__currentLoopData = $arrayEjercicios[4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>
               </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
           <?php $__currentLoopData = $arrayEjercicios[5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>

              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>
      <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
                          <?php $__currentLoopData = $arrayEjercicios[6]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>

              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">
              <?php $__currentLoopData = $arrayEjercicios[7]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>

              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>
      <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">
              <?php $__currentLoopData = $arrayEjercicios[8]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>

              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">
              <?php $__currentLoopData = $arrayEjercicios[9]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>

              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>
      <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <img class="card-img-right flex-auto d-none d-md-block" src="<?php echo e(URL::asset('rutinas/'.$arrayejercicio->imagen)); ?>" alt="Card image cap">
              <?php $__currentLoopData = $arrayEjercicios[9]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrayejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo e($arrayejercicio['ejercicio']); ?></a>

              </h3>
              <div class="mb-1 text-muted"><b>Tiempo:</b> <?php echo e($arrayejercicio['tiempo']); ?> </div>
              <div class="mb-1 text-muted"><b>Series: </b><?php echo e($entreno['serie']); ?> </div>
              <div class="mb-1 text-muted"><b>Repeticiones: </b><?php echo e($entreno['repeticiones']); ?> </div>
              <p class="card-text mb-auto"><b>Explicacion: </b><?php echo e($arrayejercicio['explicacion']); ?></p>
              <p></p>
              <p class="card-text mb-auto"><b>Material: </b><?php echo e($arrayejercicio['material']); ?></p>
              <a href="#">Continue reading</a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
      </div>s
    </div>

    <main role="main" class="container">
      <div class="row">
        <div class="col-md-8 blog-main">
          <h3 class="pb-3 mb-4 font-italic border-bottom">
            From the Firehose
          </h3>

      </div><!-- /.row -->

    </main><!-- /.container -->

    <footer class="blog-footer">
      <p>Blog template built for <a href="https://getbootstrap.com/">Bootstrap</a> by <a href="https://twitter.com/mdo">@mdo</a>.</p>
      <p>
        <a href="#">Back to top</a>
      </p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="assets/js/vendor/popper.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
    <script src="assets/js/vendor/holder.min.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>

<div class="container">
  <div class="row">
    <div class="col-md-6">

      <h2>Rutinas Personalizada</h2>

      <table class="table table-striped">
          <tr>
            <th>Informacion</th>
          </tr>
          <tr>
            <td><h1>Lunes :Rutina para BicepsTriceps </h1></td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[1]->imagen); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[2]); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[3]); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[4]); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[6]); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[7]); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[8]); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[9]); ?> </td>
            <td>BicepsEspalda:  <?php echo e($arrayBicepsPecho[0]); ?> </td>
          </tr>

          <tr>
           <td><h1>Martes :Rutina para BicepsTriceps </h1></td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
            <td>GM:  <?php echo e($arrayTricepsEspalda[1]); ?> </td>
          </tr>
          <tr>

           <td><h1>Miercoles :Rutina para BicepsTriceps </h1></td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
            <td>GM:  <?php echo e($arrayHombroAbs[1]); ?> </td>
          </tr>
          <tr>
            <td><h1>Jueves :Rutina para BicepsTriceps </h1></td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
          </tr>
          <tr>
            <td><h1>Viernes :Rutina para BicepsTriceps </h1></td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinAbsCuerpo[3]); ?> </td>
          </tr>
          <tr>
            <td><h1>Sabado :Rutina para BicepsTriceps </h1></td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinPiernasCurpo[3]); ?> </td>
          </tr>
          <tr>
            <td><h1>Domingo :Rutina para BicepsTriceps </h1></td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
            <td>GM:  <?php echo e($sinTroncoCuerpo[3]); ?> </td>
          </tr>

          <tr>
            <td>usuario:  <?php echo e($user['name']); ?> </td>
            <td>nombre:  <?php echo e($user['name']); ?> </td>
            <td>modalidad:  <?php echo e($user['modalidad']); ?> </td>
            <td>nivel:  <?php echo e($user['nivel']); ?> </td>
          </tr>
          <tr>
            <td>id:  <?php echo e($user['id']); ?> </td>
          </tr>
          <tr>
            <td>entreno:  <?php echo e($entreno); ?> </td>
          </tr>
          <tr>
            <td>ejercicio Modalidad:  <?php echo e($ejerciciomodalidad); ?> </td>
          </tr>
          <?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejercicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $ejercicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>Ejercicicos:  <?php echo e($ejer['grupo_id']); ?> </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </table>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>