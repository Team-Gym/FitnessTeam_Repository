<?php $__env->startSection('links'); ?>
    <link href="<?php echo e(asset('css/ejercicio.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container gallery-container">
    <div class="row">
        <h1 style="padding: 50px;">Ejercicios <?php echo e($nombreG->grupo); ?></h1>
    </div>
    <div class="tz-gallery">
        <div class="row">
            <?php $__currentLoopData = $ejercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ej): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4">
                    <h4 style="padding:  5px 0 15px 0"><?php echo e($ej->ejercicio); ?></h4>
                    <a class="lightbox" href="<?php echo e(URL::to('ejercicio/' . $ej->id)); ?>">
                        <img src="../rutinas/<?php echo e($ej->imagen); ?>" alt="<?php echo e($ej->ejercicio); ?>">
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>