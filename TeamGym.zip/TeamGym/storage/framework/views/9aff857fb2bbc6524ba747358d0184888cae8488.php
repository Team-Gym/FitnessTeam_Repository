<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">

			<h2>modalidads</h2>

			<table class="table table-striped">
					<tr>
						<th>Id</th>
						<th>nombre</th>
					</tr>

				<?php $__currentLoopData = $modalidads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modalidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($modalidad['id']); ?></td>
						<td><?php echo e($modalidad['nombre']); ?></td>


						<td>
							<a href="<?php echo e(route('modalidad_entreno', ['id' => $modalidad['id']])); ?>" class="btn btn-default">Ver entrenos
							<a href="<?php echo e(route('modalidad_ejerciciomodalida', ['id' => $modalidad['id']])); ?>" class="btn btn-default">Ver ejercicios de la modalidad
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>