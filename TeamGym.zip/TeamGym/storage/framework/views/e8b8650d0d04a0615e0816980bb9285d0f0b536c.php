<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">

			<h2>grupos</h2>

			<table class="table table-striped">
					<tr>
						<th>Id</th>
						<th>Grupo</th>
						<th>ejercicio</th>
					</tr>

				<?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($grupo['id']); ?></td>
						<td><?php echo e($grupo['grupo']); ?></td>


						<td>
							<a href="<?php echo e(route('grupo_editar', ['id' => $grupo['id']])); ?>" class="btn btn-default">Editar</a>

							<a href="<?php echo e(route('grupo_ejercicio', ['id' => $grupo['id']])); ?>" class="btn btn-default">Ver ejercicios por grupo

							<a href="<?php echo e(route('grupo_eliminar', ['id' => $grupo['id']])); ?>" class="btn btn-danger">Eliminar</a>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>