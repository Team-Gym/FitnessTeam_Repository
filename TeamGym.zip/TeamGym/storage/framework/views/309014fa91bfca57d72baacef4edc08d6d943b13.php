<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<h2>Semana de User</h2>

			<table class="table table-striped">
					<tr>
						<th>usuario_id</th>
						<th>lunes</th>
						<th>martes</th>
						<th>miercoles</th>
						<th>jueves</th>
						<th>viernes</th>
						<th>sabado</th>
						<th>domingo</th>
						<th>repeticiones</th>
						<th>serie</th>
						<th>peso</th>
					</tr>
					<?php $__currentLoopData = $semana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semanas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($semanas['usuario_id']); ?></td>
						<td><?php echo e($semanas['lunes']); ?></td>
						<td><?php echo e($semanas['martes']); ?></td>
						<td><?php echo e($semanas['miercoles']); ?></td>
						<td><?php echo e($semanas['jueves']); ?></td>
						<td><?php echo e($semanas['viernes']); ?></td>
						<td><?php echo e($semanas['sabado']); ?></td>
						<td><?php echo e($semanas['domingo']); ?></td>
						<td><?php echo e($semanas['repeticiones']); ?></td>
						<td><?php echo e($semanas['serie']); ?></td>
						<td><?php echo e($semanas['peso']); ?></td>
					</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>