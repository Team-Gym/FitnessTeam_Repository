<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">

			<h2>usuarios</h2>

			<table class="table table-striped">
					<tr>
						<th>Id</th>
						<th>nombre</th>
						<th>apellido</th>
						<th>email</th>
						<th>sexo</th>
						<th>dob</th>
						<th>password</th>
						<th>modalidad</th>
						<th>nivel</th>
						<th>Opciones</th>
					</tr>

				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($usuario['id']); ?></td>
						<td><?php echo e($usuario['name']); ?></td>
						<td><?php echo e($usuario['apellido']); ?></td>
						<td><?php echo e($usuario['email']); ?></td>
						<td><?php echo e($usuario['sexo']); ?></td>
						<td><?php echo e($usuario['dob']); ?></td>
						<td><?php echo e($usuario['password']); ?></td>
						<td><?php echo e($usuario['modalidad']); ?></td>
						<td><?php echo e($usuario['nivel']); ?></td>
						<td>
							<a href="<?php echo e(route('usuario_editar', ['id' => $usuario['id']])); ?>" class="btn btn-default">Editar</a>
							<a href="<?php echo e(route('usuario_semana', ['id' => $usuario['id']])); ?>" class="btn btn-default">Ver semana</a>
							<a href="<?php echo e(route('usuario_eliminar', ['id' => $usuario['id']])); ?>" class="btn btn-danger">Eliminar</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



			</table>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>