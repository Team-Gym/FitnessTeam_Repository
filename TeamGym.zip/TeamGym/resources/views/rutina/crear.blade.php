@extends('layouts.app')

@section('content')


<div class="container">



        <div class="col-md-12 px-0">
         <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary">World</strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"> {{$user['name']}}</a>
              <div class="mb-1 text-muted">Inicio {{date('d-m-Y', strtotime($user['created_at']))}}</div>
              <p class="card-text mb-auto">Modalidad {{$user['modalidad']}}</p>
              <p class="card-text mb-auto">Nivel {{$user['nivel']}}</p>
              <a href="#">Saver mas</a>
            </div>
                <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('usuarios/usuario1.png')}}" alt="Card image cap">
          </div>



      </div>

            <?php
$arrayEjercicios = array();

for ($i = 0; $i < count($ejercicios); $i++) {
    $arrayEjercicios[$i] = $ejercicios[$i];
    //echo $arrayEjercicios[$i];
}
?>
      <div class="row mb-3">
        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[0]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[0]->ejercicio}}</a>
                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[0]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[0]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[0]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[1]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[1]->ejercicio}}</a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[1]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[1]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[1]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>
      <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[2]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[2]->ejercicio}}</a>
                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[2]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[2]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[2]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[4]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[4]->ejercicio}}</a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[4]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[4]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[4]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[6]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[6]->ejercicio}}</a>
                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[6]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[6]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[6]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[7]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[7]->ejercicio}}</a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[7]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[7]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[7]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>



      <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[8]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[8]->ejercicio}}</a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[8]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[8]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[8]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>


        <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[9]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[9]->ejercicio}}</a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[9]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[9]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[9]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>

      <div class="col-md-6">
                <div class="card flex-md-row mb-4 box-shadow h-md-250">
                  <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$arrayBicepsPecho[9]->imagen)}}" alt="Card image cap">

                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">World</strong>
                    <h3 class="mb-0">
                      <a class="text-dark" href="#">{{$arrayBicepsPecho[9]->ejercicio}}</a>

                    </h3>
                    <div class="mb-1 text-muted"><b>Tiempo:</b> {{$arrayBicepsPecho[9]->tiempo}} </div>
                    <div class="mb-1 text-muted"><b>Series: </b>{{$entreno['serie']}} </div>
                    <div class="mb-1 text-muted"><b>Repeticiones: </b>{{$entreno['repeticiones']}} </div>
                    <p class="card-text mb-auto"><b>Explicacion: </b>{{$arrayBicepsPecho[9]->explicacion}}</p>
                    <p></p>
                    <p class="card-text mb-auto"><b>Material: </b>{{$arrayBicepsPecho[9]->material}}</p>
                    <a href="#">Continue reading</a>
                  </div>
                </div>
              </div>


    </div>

    <main role="main" class="container">
      <div class="row">
        <div class="col-md-8 blog-main">
          <h3 class="pb-3 mb-4 font-italic border-bottom">
            From the Firehose
          </h3>

      </div><!-- /.row -->

    </main><!-- /.container -->

    <footer class="blog-footer">
      <p>Blog template built for <a href="https://getbootstrap.com/">Bootstrap</a> by <a href="https://twitter.com/mdo">@mdo</a>.</p>
      <p>
        <a href="#">Back to top</a>
      </p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="assets/js/vendor/popper.min.js"></script>
    <script src="dist/js/bootstrap.min.js"></script>
    <script src="assets/js/vendor/holder.min.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>



@stop
