@extends('layouts.menu')

@section('content')
    <h2>Aqui viene el contenido</h2>
@endsection