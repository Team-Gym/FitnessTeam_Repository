@extends('layouts.app')

@section('content')

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<h2></h2>
<?php
echo var_dump($ejercicios);
?>
 @foreach($ejercicios as $ejercicio)
			<div class="col-md-6">
	          <div class="card flex-md-row mb-4 box-shadow h-md-250">


		            <img class="card-img-right flex-auto d-none d-md-block" src="{{URL::asset('rutinas/'.$ejercicio->imagen)}}" alt="Card image cap">

		            <div class="card-body d-flex flex-column align-items-start">
		              <strong class="d-inline-block mb-2 text-primary">World</strong>
		              <h3 class="mb-0">
		                <a class="text-dark" href="#">{{$ejercicio['ejercicio']}}</a>
		              </h3>
		              <div class="mb-1 text-muted"><b>Tiempo:</b> {{$ejercicio['tiempo']}} </div>
		              <p class="card-text mb-auto"><b>Explicacion: </b>{{$ejercicio['explicacion']}}</p>
		              <p></p>
		              <p class="card-text mb-auto"><b>Material: </b>{{$ejercicio['material']}}</p>
		              <a href="#">Continue reading</a>

		            </div>

		          </div>
		      </div>
@endforeach
			<table class="table table-striped">
					<tr>
						<th>ejercicio_id</th>
						<th>modalidad_id</th>
						<th>Opciones</th>
					</tr>
					@foreach($ejerciciomodalidad as $ejerciciomodalidads)
					<tr>
						<td>{{$ejerciciomodalidads['ejercicio_id']}}</td>
						<td>{{$ejerciciomodalidads['modalidad_id']}}</td>
					</tr>

					@endforeach


			</table>

		</div>
	</div>
</div>

@stop
