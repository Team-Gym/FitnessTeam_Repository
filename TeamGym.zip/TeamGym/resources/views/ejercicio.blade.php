@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h1>{{$ejercicio->ejercicio}}</h1>
        </div>
        <div class="col-lg-6 d-flex align-items-center justify-content-center bg-secondary">
            <img src="../rutinas/{{$ejercicio->imagen}}">
        </div>
        <div class="col-lg-6 bg-primary">
            <div class="row">
                <div class="col-lg-6 borde">
                    <h6>TIEMPO</h6> <p>{{$ejercicio->tiempo}}</p>
                </div>
                <div class="col-lg-6">
                    <h6>MATERIAL</h6> <p>{{$ejercicio->material}}</p>
                </div>
            </div>
            <div class="col-lg-12 pt-2">
                <h6>EXPLICACION DEL EJERCICIO</h6>
                <p>{{$ejercicio->explicacion}}</p>
                <h6>CONSEJOS</h6>
                <p>{{$ejercicio->posicion}}</p>
            </div>

        </div>
    </div>
</div>
@endsection
